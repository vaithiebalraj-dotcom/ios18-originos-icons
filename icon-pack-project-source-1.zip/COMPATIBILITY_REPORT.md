# Compatibility Report - iQOO Neo 10R / OriginOS

Date: 2026-10-21

## Confirmed (from iQOO community / news sources)
- iQOO Neo 10R received OriginOS 6 (Android 16); builds such as PD2352BF_EX_A_16.1.16.1.W30 (May 2026) are documented.
- Community posts say extra icon styles/sizes are currently China-version features, not in global OriginOS 6.

## NOT confirmed (no documentation found)
- A theme/icon-pack import path in global OriginOS 6 that accepts third-party icons.
- Any official OriginOS format for third-party icon packs. A Xiaomi/POCO .mtz was NOT built and would not be valid.
- That the APK in this project changes stock-launcher icons. It does not claim to, and this was NOT tested on a device.

## What this project actually is
- 28 original squircle icons (512x512 PNG, transparent corners) plus a small Android app that previews them.
- A standard ADW/Nova-style `appfilter.xml` with a few UNVERIFIED mappings. Only icon-pack-aware apps/launchers read it.
- Brand apps (video, social, chat, web, inbox, store) get neutral original designs, not the real logos.

## Not tested
- The APK was not built here (no Android SDK in this environment, no access to Google's SDK/Maven servers). It has never been run.

## Closest viable options (none verified on your phone)
1. Check Settings > Wallpaper & style / personalization on the device for any icon style option.
2. Use the PNGs manually where an app lets you pick a custom image.
3. A launcher or Xposed-based tool that reads icon packs (needs a launcher swap or root-level tooling, which you excluded).
