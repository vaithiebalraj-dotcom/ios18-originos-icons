package com.example.iospackpreview;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Simple preview screen: shows every icon in the pack in a grid. */
public class MainActivity extends Activity {

    private static final String[] NAMES = {
        "phone", "messages", "contacts", "camera", "photos", "settings", "calendar", "clock",
        "browser", "mail", "notes", "reminders", "maps", "weather", "music", "store", "files",
        "calculator", "gallery", "downloads", "video", "social", "chat", "web", "inbox",
        "playstore", "health", "recorder"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final float d = getResources().getDisplayMetrics().density;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#101018"));
        root.setPadding((int) (16 * d), (int) (40 * d), (int) (16 * d), 0);

        TextView title = new TextView(this);
        title.setText(getString(R.string.app_name) + " - " + NAMES.length + " icons");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setPadding(0, 0, 0, (int) (12 * d));
        root.addView(title);

        GridView grid = new GridView(this);
        grid.setNumColumns(4);
        grid.setVerticalSpacing((int) (14 * d));
        grid.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return NAMES.length; }
            @Override public Object getItem(int i) { return NAMES[i]; }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View convert, ViewGroup parent) {
                LinearLayout cell = new LinearLayout(MainActivity.this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER_HORIZONTAL);
                ImageView iv = new ImageView(MainActivity.this);
                int id = getResources().getIdentifier(NAMES[i], "drawable", getPackageName());
                iv.setImageResource(id);
                iv.setLayoutParams(new LinearLayout.LayoutParams((int) (64 * d), (int) (64 * d)));
                TextView tv = new TextView(MainActivity.this);
                tv.setText(NAMES[i]);
                tv.setTextColor(Color.LTGRAY);
                tv.setTextSize(11);
                tv.setGravity(Gravity.CENTER);
                cell.addView(iv);
                cell.addView(tv);
                return cell;
            }
        });
        root.addView(grid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
    }
}
