# Squircle Icon Pack (iOS-inspired) - iQOO Neo 10R / OriginOS 6

Original artwork: 28 icons, 512x512 PNG, transparent outside the rounded shape.
Not copies of Apple, Google or Meta logos.

## Contents
- `icons/` - the individual PNGs (also in `drawable-nodpi`)
- `tools/gen_icons.py` - regenerates every icon (Python + Pillow)
- `app/` - Android Studio project: preview screen + `appfilter.xml`
- `build_debug.sh` - builds the debug APK
- `COMPATIBILITY_REPORT.md` - what is and is not confirmed

## Build
1. Install JDK 17 and Android SDK (platform 34, build-tools 34).
2. Set `ANDROID_HOME`, run `./build_debug.sh`.
3. APK: `app/build/outputs/apk/debug/app-debug.apk`.
   (Not built in the authoring environment, see report and BUILD_LOG.txt.)

## Install / use on OriginOS - honest version
No documented way to import third-party icon packs into the stock OriginOS 6 launcher was found, and none has been tested.
Installing this APK only gives you a preview app. It will not change your home screen by itself.
Options: apply individual PNGs where an app allows a custom image, or use an icon-pack-aware tool (this needs a launcher or tooling you said you do not want).
