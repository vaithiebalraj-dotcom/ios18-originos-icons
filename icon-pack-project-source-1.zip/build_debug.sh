#!/usr/bin/env bash
# Builds the debug APK. Requires JDK 17+ and an Android SDK (ANDROID_HOME set,
# or sdk.dir in local.properties) with platform android-34 + build-tools 34.
set -euo pipefail
cd "$(dirname "$0")"
if [ -z "${ANDROID_HOME:-}" ] && [ ! -f local.properties ]; then
  echo "ERROR: Android SDK not found. Set ANDROID_HOME or create local.properties (sdk.dir=...)." >&2
  exit 1
fi
if [ -x ./gradlew ]; then GRADLE=./gradlew; else GRADLE=gradle; fi
$GRADLE --no-daemon assembleDebug
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
