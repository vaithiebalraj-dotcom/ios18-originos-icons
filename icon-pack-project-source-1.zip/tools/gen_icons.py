#!/usr/bin/env python3
"""Generates original iOS-style (squircle, soft gradient) 512x512 icons.
All artwork is drawn from scratch with simple geometric glyphs; it is not a copy of
any vendor's icon or brand logo."""
import math, os, sys, glob
from PIL import Image, ImageDraw, ImageFont, ImageChops, ImageFilter

S = 1024          # supersampled canvas
OUT = 512
OUTDIR = sys.argv[1] if len(sys.argv) > 1 else "icons"
os.makedirs(OUTDIR, exist_ok=True)

FONT = None
for p in glob.glob("/usr/share/fonts/**/DejaVuSans-Bold.ttf", recursive=True):
    FONT = p
    break

def font(sz):
    return ImageFont.truetype(FONT, sz) if FONT else ImageFont.load_default()

def hexc(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4)) + (255,)

def grad(c1, c2, angle_vertical=True):
    c1, c2 = hexc(c1), hexc(c2)
    g = Image.new("RGBA", (S, S))
    d = ImageDraw.Draw(g)
    for y in range(S):
        t = y / (S - 1)
        d.line([(0, y), (S, y)], fill=tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(4)))
    return g

def squircle_mask(n=5.0, margin=0):
    pts = []
    r = S / 2 - margin
    for i in range(720):
        a = 2 * math.pi * i / 720
        ca, sa = math.cos(a), math.sin(a)
        x = r * math.copysign(abs(ca) ** (2 / n), ca)
        y = r * math.copysign(abs(sa) ** (2 / n), sa)
        pts.append((S / 2 + x, S / 2 + y))
    m = Image.new("L", (S, S), 0)
    ImageDraw.Draw(m).polygon(pts, fill=255)
    return m

MASK = squircle_mask()

def finish(img, name):
    # soft top gloss + thin inner edge for depth
    gloss = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    gd = ImageDraw.Draw(gloss)
    gd.ellipse([-300, -820, S + 300, 380], fill=(255, 255, 255, 18))
    img = Image.alpha_composite(img, gloss)
    edge = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    inner = ImageChops.subtract(MASK, MASK.filter(ImageFilter.MinFilter(9)))
    edge.putalpha(inner.point(lambda v: v // 6))
    img = Image.alpha_composite(img, edge)
    img.putalpha(ImageChops.multiply(img.getchannel("A"), MASK))
    img.resize((OUT, OUT), Image.LANCZOS).save(os.path.join(OUTDIR, name + ".png"))

def canvas(bg):
    if isinstance(bg, tuple):
        base = grad(*bg)
    else:
        base = Image.new("RGBA", (S, S), hexc(bg))
    return base, ImageDraw.Draw(base)

W = (255, 255, 255, 255)
def rr(d, box, r, fill):
    d.rounded_rectangle(box, r, fill=fill)

def circ(d, cx, cy, r, fill):
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=fill)

ICONS = {}
def icon(name):
    def deco(f):
        ICONS[name] = f
        return f
    return deco

@icon("phone")
def _():
    im, d = canvas(("#5BE06F", "#1DB954"))
    pts = []
    for i in range(41):
        a = math.radians(95 + 80 * i / 40)
        pts.append((640 + 300 * math.cos(a), 384 + 300 * math.sin(a)))
    for x, y in pts:
        circ(d, x, y, 62, W)
    circ(d, pts[0][0] + 10, pts[0][1] + 10, 100, W)
    circ(d, pts[-1][0] - 10, pts[-1][1] - 10, 100, W)
    return im

@icon("messages")
def _():
    im, d = canvas(("#6CE67E", "#22B84A"))
    d.ellipse([170, 200, 854, 700], fill=W)
    d.polygon([(260, 640), (230, 820), (430, 690)], fill=W)
    return im

@icon("contacts")
def _():
    im, d = canvas(("#C9CED6", "#8E96A3"))
    circ(d, 512, 380, 150, W)
    d.pieslice([232, 560, 792, 1120], 180, 360, fill=W)
    return im

@icon("camera")
def _():
    im, d = canvas(("#D9DCE1", "#9AA0AA"))
    rr(d, [150, 290, 874, 790], 90, (40, 42, 48, 255))
    rr(d, [330, 230, 560, 320], 30, (40, 42, 48, 255))
    circ(d, 512, 540, 175, (230, 232, 238, 255))
    circ(d, 512, 540, 135, (30, 32, 40, 255))
    circ(d, 512, 540, 70, (70, 90, 140, 255))
    circ(d, 760, 380, 22, (255, 190, 60, 255))
    return im

@icon("photos")
def _():
    im, d = canvas("#FFFFFF")
    cols = ["#FF6B5B", "#FFA83D", "#FFD83D", "#6FD66B", "#3BC7D8", "#4C8DFF", "#8A63F0", "#E05BC7"]
    for i, c in enumerate(cols):
        a = 2 * math.pi * i / 8
        lay = Image.new("RGBA", (S, S), (0, 0, 0, 0))
        circ(ImageDraw.Draw(lay), 512 + 170 * math.cos(a), 512 + 170 * math.sin(a), 150, hexc(c)[:3] + (170,))
        im.alpha_composite(lay)
    return im

@icon("settings")
def _():
    im, d = canvas(("#B7BDC6", "#7C838F"))
    for i in range(8):
        a = 2 * math.pi * i / 8
        cx, cy = 512 + 270 * math.cos(a), 512 + 270 * math.sin(a)
        circ(d, cx, cy, 70, (60, 64, 72, 255))
    circ(d, 512, 512, 300, (60, 64, 72, 255))
    circ(d, 512, 512, 130, (170, 176, 186, 255))
    return im

@icon("calendar")
def _():
    im, d = canvas("#FFFFFF")
    d.text((512, 220), "TUE", font=font(120), fill=hexc("#F04438"), anchor="mm")
    d.text((512, 600), "21", font=font(440), fill=(30, 30, 34, 255), anchor="mm")
    return im

@icon("clock")
def _():
    im, d = canvas("#1C1C1F")
    circ(d, 512, 512, 440, W)
    for i in range(60):
        a = 2 * math.pi * i / 60
        big = i % 5 == 0
        r1, r2 = (380, 420) if big else (400, 420)
        d.line([(512 + r1 * math.sin(a), 512 - r1 * math.cos(a)), (512 + r2 * math.sin(a), 512 - r2 * math.cos(a))],
               fill=(30, 30, 34, 255), width=14 if big else 6)
    d.line([(512, 512), (512 + 200 * math.sin(math.radians(300)), 512 - 200 * math.cos(math.radians(300)))], fill=(30, 30, 34, 255), width=34)
    d.line([(512, 512), (512 + 310 * math.sin(math.radians(60)), 512 - 310 * math.cos(math.radians(60)))], fill=(30, 30, 34, 255), width=24)
    d.line([(512, 512), (512 + 340 * math.sin(math.radians(180)), 512 - 340 * math.cos(math.radians(180)))], fill=hexc("#FF9F0A"), width=10)
    circ(d, 512, 512, 24, hexc("#FF9F0A"))
    return im

@icon("browser")
def _():
    im, d = canvas(("#4FB4FF", "#1767E6"))
    d.ellipse([170, 170, 854, 854], outline=W, width=44)
    d.ellipse([360, 170, 664, 854], outline=W, width=36)
    d.line([(170, 512), (854, 512)], fill=W, width=36)
    d.arc([170, 300, 854, 724], 0, 360, fill=W, width=1)
    d.line([(230, 340), (794, 340)], fill=W, width=28)
    d.line([(230, 684), (794, 684)], fill=W, width=28)
    return im

@icon("mail")
def _():
    im, d = canvas(("#5AB7FF", "#1668E3"))
    rr(d, [140, 270, 884, 754], 70, W)
    d.line([(170, 320), (512, 560), (854, 320)], fill=hexc("#2A7BEF"), width=44, joint="curve")
    return im

@icon("notes")
def _():
    im, d = canvas("#FFFDF4")
    d.rectangle([0, 0, S, 230], fill=hexc("#FFCC2E"))
    for y in (400, 540, 680, 820):
        d.line([(110, y), (914, y)], fill=(225, 220, 200, 255), width=8)
    d.line([(110, 400), (600, 400)], fill=(190, 185, 170, 255), width=14)
    return im

@icon("reminders")
def _():
    im, d = canvas("#FFFFFF")
    for y, c in ((260, "#FF5A4F"), (512, "#FFA21A"), (764, "#4C8DFF")):
        circ(d, 220, y, 58, hexc(c))
        circ(d, 220, y, 36, W)
        d.line([(340, y), (880, y)], fill=(215, 215, 222, 255), width=16)
    return im

@icon("maps")
def _():
    im, d = canvas(("#C8EBB0", "#8FD16F"))
    d.polygon([(0, 620), (S, 380), (S, 520), (0, 760)], fill=hexc("#F3F0E4"))
    d.polygon([(580, 0), (700, 0), (520, S), (400, S)], fill=hexc("#FFE08A"))
    d.rectangle([0, 800, S, S], fill=hexc("#7CC3F0"))
    circ(d, 512, 400, 190, hexc("#F04438"))
    d.polygon([(380, 520), (644, 520), (512, 780)], fill=hexc("#F04438"))
    circ(d, 512, 400, 78, W)
    return im

@icon("weather")
def _():
    im, d = canvas(("#4DB8FF", "#2E6FE0"))
    circ(d, 400, 380, 170, hexc("#FFD43B"))
    for c in ((420, 640, 150), (610, 600, 190), (760, 690, 120)):
        circ(d, c[0], c[1], c[2], W)
    rr(d, [300, 650, 840, 800], 75, W)
    return im

@icon("music")
def _():
    im, d = canvas(("#FF6B8A", "#F0273F"))
    d.line([(420, 700), (420, 270), (720, 220), (720, 640)], fill=W, width=56, joint="curve")
    d.ellipse([280, 640, 450, 780], fill=W)
    d.ellipse([580, 590, 750, 730], fill=W)
    return im

@icon("store")
def _():
    im, d = canvas(("#3DB2FF", "#1659E6"))
    rr(d, [230, 360, 794, 800], 60, W)
    d.arc([340, 190, 684, 530], 180, 360, fill=W, width=58)
    circ(d, 400, 440, 28, hexc("#1F6FEA")); circ(d, 624, 440, 28, hexc("#1F6FEA"))
    return im

@icon("files")
def _():
    im, d = canvas("#FFFFFF")
    rr(d, [140, 250, 520, 420], 50, hexc("#58A8FF"))
    rr(d, [140, 330, 884, 780], 70, hexc("#2E86F5"))
    return im

@icon("calculator")
def _():
    im, d = canvas("#2A2B2F")
    rr(d, [150, 130, 874, 330], 40, (60, 62, 68, 255))
    d.text((820, 232), "0", font=font(150), fill=W, anchor="rm")
    for r in range(4):
        for c in range(4):
            col = hexc("#FF9F0A") if c == 3 else (hexc("#5A5C63") if r else hexc("#A5A6AB"))
            circ(d, 232 + c * 187, 470 + r * 150, 62, col)
    return im

@icon("gallery")
def _():
    im, d = canvas(("#8F8CFF", "#5A3FE0"))
    rr(d, [150, 200, 874, 824], 70, W)
    circ(d, 330, 400, 60, hexc("#FFC53D"))
    d.polygon([(150, 780), (420, 460), (600, 680), (720, 560), (874, 750), (874, 824), (150, 824)], fill=hexc("#5FC47A"))
    return im

@icon("downloads")
def _():
    im, d = canvas(("#32D7B2", "#0E9E8C"))
    d.polygon([(400, 190), (624, 190), (624, 440), (760, 440), (512, 700), (264, 440), (400, 440)], fill=W)
    rr(d, [200, 740, 824, 840], 40, W)
    return im

@icon("video")
def _():
    im, d = canvas(("#8C7BFF", "#3F2FD0"))
    circ(d, 512, 512, 330, W)
    d.polygon([(430, 360), (430, 664), (690, 512)], fill=hexc("#4B3BE0"))
    return im

@icon("social")
def _():
    im, d = canvas(("#7C6CFF", "#E552B5"))
    circ(d, 512, 380, 120, W); d.pieslice([300, 520, 724, 960], 180, 360, fill=W)
    circ(d, 290, 440, 80, (255, 255, 255, 220)); circ(d, 734, 440, 80, (255, 255, 255, 220))
    return im

@icon("chat")
def _():
    im, d = canvas(("#3CE0A8", "#0FA37F"))
    d.ellipse([170, 190, 854, 690], fill=W)
    d.polygon([(250, 620), (190, 830), (430, 680)], fill=W)
    for x in (360, 512, 664):
        circ(d, x, 440, 40, hexc("#0FA37F"))
    return im

@icon("web")
def _():
    im, d = canvas(("#FFB347", "#F0701A"))
    rr(d, [140, 220, 884, 804], 70, W)
    d.rounded_rectangle([140, 220, 884, 360], 70, fill=hexc("#F7E3CC"))
    d.rectangle([140, 300, 884, 360], fill=hexc("#F7E3CC"))
    for x in (230, 310, 390):
        circ(d, x, 290, 22, hexc("#F0701A"))
    rr(d, [200, 410, 824, 500], 45, hexc("#F3F3F5"))
    d.rectangle([200, 560, 560, 590], fill=hexc("#E3E3E8"))
    d.rectangle([200, 640, 700, 670], fill=hexc("#E3E3E8"))
    return im

@icon("inbox")
def _():
    im, d = canvas(("#FFD166", "#F59E0B"))
    d.polygon([(200, 560), (330, 260), (694, 260), (824, 560), (824, 780), (200, 780)], fill=W)
    d.polygon([(200, 560), (400, 560), (440, 650), (584, 650), (624, 560), (824, 560), (824, 780), (200, 780)], fill=hexc("#FDEBC8"))
    d.line([(400, 560), (440, 650), (584, 650), (624, 560)], fill=hexc("#F59E0B"), width=26, joint="curve")
    return im

@icon("playstore")
def _():
    im, d = canvas(("#6D7CFF", "#2D3FD6"))
    for i, (x, y) in enumerate(((190, 190), (544, 190), (190, 544), (544, 544))):
        rr(d, [x, y, x + 290, y + 290], 80, W if i != 3 else hexc("#BFC7FF"))
    return im

@icon("health")
def _():
    im, d = canvas("#FFFFFF")
    circ(d, 390, 410, 170, hexc("#FF3B6B")); circ(d, 634, 410, 170, hexc("#FF3B6B"))
    d.polygon([(235, 510), (789, 510), (512, 840)], fill=hexc("#FF3B6B"))
    return im

@icon("recorder")
def _():
    im, d = canvas(("#3A3A3F", "#1A1A1D"))
    rr(d, [400, 190, 624, 560], 112, hexc("#FF4B3E"))
    d.arc([300, 340, 724, 740], 0, 180, fill=W, width=40)
    d.line([(512, 740), (512, 850)], fill=W, width=40)
    d.line([(400, 850), (624, 850)], fill=W, width=40)
    return im

if __name__ == "__main__":
    for n, f in ICONS.items():
        finish(f(), n)
    print(len(ICONS), "icons written to", OUTDIR)
